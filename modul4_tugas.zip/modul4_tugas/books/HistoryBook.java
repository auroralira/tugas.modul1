package modul4.tugas.books;

public class HistoryBook extends Book{
    public HistoryBook(String idBuku, String judul, int stok, String category, String author) {
        super(idBuku, judul, stok, category, author);
    }
}
